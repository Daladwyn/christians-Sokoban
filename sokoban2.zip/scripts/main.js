alert("hello Warehouse managers!");

console.log("now has the game started.")
var player = {
	row : 0,
	col : 0,
	newrow : 0,
	newcol : 0,
}
var position ="r0c0";
var mapBegins = document.getElementById("Map");
for (var y=0;y<mapsArray[0].height;y++){
	for(var x=0;x<mapsArray[0].width+1;x++){
		position="r"+y+"c"+x;
		var cell= document.createElement("div");
		cell.setAttribute("id", position);
		mapBegins.appendChild(cell);
		if(x==19){
			lineBreak=document.createElement("div");
			lineBreak.setAttribute("style","display:block;margin:opx;padding:0px;border:0px;");
			var item = document.getElementById(position);
			mapBegins.appendChild(lineBreak);
		}
	}
}
alert("grundutskrift klar");
printMap();
//var keypressed = event.key;
do{
document.onkeyup = function(event){
	event=event || window.event;
	//event.preventDefault();
var keypressed = event.key;
console.log("key pressed is: "+keypressed);
switch(keypressed){
case "ArrowUp":
	player.newrow=player.row;
	player.newrow=player.newrow-1;
	console.log("gamal rad: "+player.row+ " ny rad :"+player.newrow);;
	
	console.log("gamal karta: "+mapsArray[0].mapGrid[player.row][player.col]);
	mapsArray[0].mapGrid[player.row][player.col]= " ";
	console.log("gamal karta efter flytt: "+mapsArray[0].mapGrid[player.row][player.col]);
	
	console.log("ny karta: "+mapsArray[0].mapGrid[player.newrow][player.col]);
	mapsArray[0].mapGrid[player.newrow][player.col]= "P";
	console.log("ny karta: "+mapsArray[0].mapGrid[player.newrow][player.col]);
	
	player.row=player.newrow;
	break;
case "ArrowDown":
	player.newrow=player.row;
	player.newrow=player.newrow++;
	mapsArray[0].mapGrid[player.row][player.col]= " ";
	mapsArray[0].mapGrid[player.newrow][player.col]= "P";
	player.row=player.newrow;
	break;
case "ArrowLeft":
	player.newcol=player.col;
	player.newcol=player.newcol--;
	mapsArray[0].mapGrid[player.row][player.col]= " ";
	mapsArray[0].mapGrid[player.row][player.newcol]= "P";
	
	break;
case "ArrowRight":
	player.newcol=player.col;
	player.newcol=player.newcol++;
	mapsArray[0].mapGrid[player.row][player.col]= " ";
	mapsArray[0].mapGrid[player.row][player.newcol]= "P";
	
	break;
default:
	break;
}

printMap();
}
}while (keypressed !="Escape");

	
//print out the map
function printMap(){
	var position ="r0c0";
	//var lineBreak =document.createElement("div"); //initialize a linebreak element
	console.log("start position "+position);
	var mapBegins = document.getElementById("Map");
	//var mapBegins = document.createElement("div");
	//mapBegins = document.createTextNode('<div id="r0c0"></div>');

	//var displayMap = document.createTextNode(" ");
//console.log("mapsarray har "+mapsArray.length+" element");
//console.log("mapsarray[0].mapGrid har "+mapsArray[0].mapGrid.length+" element");
//console.log("mapsarray[0].mapGrid[0] har "+mapsArray[0].mapGrid[0].length+" element");
//console.log("mapsarray[0].mapGrid[0][0] har "+mapsArray[0].mapGrid[0][0].length+" element som är: "+mapsArray[0].mapGrid[11][11]);

	//lineBreak.setAttribute("id",position);
	//document.getElementById("Map").appendChild(lineBreak);

for (var y=0;y<mapsArray[0].height;y++){
	for(var x=0;x<mapsArray[0].width+1;x++){
		position="r"+y+"c"+x;
		console.log("nuvarande position "+position);
		if(mapsArray[0].mapGrid[y][x] == " "){   //if element is a outside the game or a pass throu
			displayPicture("tile","tile-space");
		}
		else if (mapsArray[0].mapGrid[y][x] == "W"){ //if element is a wall
			displayPicture("tile","tile-wall");
		}
		else if (mapsArray[0].mapGrid[y][x] =="B"){  //if element is a crate
			displayPicture("entity","entity-block");
		}
		else if (mapsArray[0].mapGrid[y][x] =="G"){   //if the space is a final positions for a crate
			displayPicture("tile","tile-goal");
		}
		else if (mapsArray[0].mapGrid[y][x] =="P"){   //this is where the player is
			displayPicture("entity","entity-player");
			player.row= y;
			player.col= x;
		}
		
	}
	
}

	function displayPicture(typeOfEntity,pictureClass){
		var output = document.createElement("div");
		output.setAttribute("id", position);
		output.setAttribute("class", typeOfEntity);
		output.setAttribute("class", pictureClass);
		
		console.log("output blev "+output);
		var itemToBeRemoved = document.getElementById(position);
		//console.log("out: " + output);
		//console.log("item: " + itemToBeRemoved);
		mapBegins.replaceChild(output,itemToBeRemoved);
			
		
	}
	alert("Map is printed");
}
//keypressed key eventhandeler
function startGame(){
	console.log("now has the game started.")
	printMap();
	var keypressed = document.body.onkeyup();
	console.log("key pressed is: "+keypressed);
	
	//document.getElementById=("startGame").onclick =startGame;
	
	
}
//alert("game is over.");
